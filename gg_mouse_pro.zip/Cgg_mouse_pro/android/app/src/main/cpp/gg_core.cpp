#include <jni.h>
#include <cmath>
#include <algorithm>
#include <android/log.h>

#define LOG_TAG "GG_CORE_NATIVE"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

struct EngineConfig {
    float sensX = 1.0f;
    float sensY = 1.2f;
    float smoothing = 0.65f;
    bool aimAssistEnabled = true;
    bool antiRecoilEnabled = true;
    float deadZoneThreshold = 1.0f; 
    float recoilCompensation = 2.2f; 
};

static EngineConfig g_Config;
static bool g_IsEngineRunning = false;

struct MotionVector {
    float dx;
    float dy;
};

class AimAssistEngine {
public:
    static MotionVector ProcessInput(float rawDx, float rawDy) {
        MotionVector result = {rawDx, rawDy};
        float magnitude = std::sqrt(result.dx * result.dx + result.dy * result.dy);
        
        if (magnitude < g_Config.deadZoneThreshold) {
            return {0.0f, 0.0f};
        }

        result.dx *= g_Config.sensX;
        result.dy *= g_Config.sensY;

        if (g_Config.aimAssistEnabled) {
            float dampingFactor = 1.0f / (1.0f + (g_Config.smoothing * magnitude * 0.08f));
            result.dx *= dampingFactor;
            result.dy *= dampingFactor;
        }

        if (g_Config.antiRecoilEnabled) {
            result.dy += g_Config.recoilCompensation;
        }

        return result;
    }
};

extern "C" {
JNIEXPORT void JNICALL
Java_com_ggmouse_pro_NativeBridge_updateConfig(JNIEnv* env, jobject thiz, jfloat sensX, jfloat sensY, jfloat smoothing, jboolean aimAssist, jboolean antiRecoil) {
    g_Config.sensX = sensX;
    g_Config.sensY = sensY;
    g_Config.smoothing = smoothing;
    g_Config.aimAssistEnabled = aimAssist;
    g_Config.antiRecoilEnabled = antiRecoil;
}

JNIEXPORT jboolean JNICALL
Java_com_ggmouse_pro_NativeBridge_startEngine(JNIEnv* env, jobject thiz) {
    g_IsEngineRunning = true;
    LOGI("Motor NDK ativado.");
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_ggmouse_pro_NativeBridge_stopEngine(JNIEnv* env, jobject thiz) {
    g_IsEngineRunning = false;
    LOGI("Motor NDK desativado.");
    return JNI_TRUE;
}

JNIEXPORT jfloatArray JNICALL
Java_com_ggmouse_pro_NativeBridge_processMotionDelta(JNIEnv* env, jobject thiz, jfloat rawDx, jfloat rawDy) {
    if (!g_IsEngineRunning) {
        jfloatArray arr = env->NewFloatArray(2);
        jfloat def[2] = {rawDx, rawDy};
        env->SetFloatArrayRegion(arr, 0, 2, def);
        return arr;
    }
    MotionVector processed = AimAssistEngine::ProcessInput(rawDx, rawDy);
    jfloatArray resultArray = env->NewFloatArray(2);
    jfloat vec[2] = {processed.dx, processed.dy};
    env->SetFloatArrayRegion(resultArray, 0, 2, vec);
    return resultArray;
}
}
