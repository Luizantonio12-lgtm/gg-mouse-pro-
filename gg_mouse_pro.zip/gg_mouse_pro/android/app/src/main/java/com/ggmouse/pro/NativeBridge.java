package com.ggmouse.pro;

import androidx.annotation.NonNull;
import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

public class NativeBridge implements FlutterPlugin, MethodChannel.MethodCallHandler {
    private MethodChannel channel;

    static {
        System.loadLibrary("gg_core");
    }

    public native void updateConfig(float sensX, float sensY, float smoothing, boolean aimAssist, boolean antiRecoil);
    public native boolean startEngine();
    public native boolean stopEngine();
    public native float[] processMotionDelta(float rawDx, float rawDy);

    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding binding) {
        channel = new MethodChannel(binding.getBinaryMessenger(), "com.ggmouse.pro/core");
        channel.setMethodCallHandler(this);
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
        switch (call.method) {
            case "updateConfig":
                updateConfig(
                    ((Number) call.argument("sensX")).floatValue(),
                    ((Number) call.argument("sensY")).floatValue(),
                    ((Number) call.argument("smoothing")).floatValue(),
                    call.argument("aimAssist"),
                    call.argument("antiRecoil")
                );
                result.success(true);
                break;
            case "startEngine":
                result.success(startEngine());
                break;
            case "stopEngine":
                result.success(stopEngine());
                break;
            default:
                result.notImplemented();
                break;
        }
    }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
        channel.setMethodCallHandler(null);
    }
}

