import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:usb_serial/usb_serial.dart';

void main() {
  runApp(const GGMouseProApp());
}

class GGMouseProApp extends StatelessWidget {
  const GGMouseProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GG Mouse Pro AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0D0E12),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00E5FF),
          secondary: Color(0xFF7C4DFF),
          surface: Color(0xFF16181F),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  static const MethodChannel _nativeChannel = MethodChannel('com.ggmouse.pro/core');

  double _sensX = 1.0;
  double _sensY = 1.1;
  double _smoothing = 0.65;
  bool _aimAssistEnabled = true;
  bool _antiRecoilEnabled = true;
  bool _autoCalibrateEnabled = false;
  bool _isOptimizing = false;
  
  String _deviceStatus = 'Aguardando Periférico OTG...';
  bool _isConnected = false;
  StreamSubscription<UsbEvent>? _usbSubscription;
  Timer? _autoCalibrationTimer;

  @override
  void initState() {
    super.initState();
    _initUsbListener();
  }

  @override
  void dispose() {
    _usbSubscription?.cancel();
    _autoCalibrationTimer?.cancel();
    super.dispose();
  }

  void _initUsbListener() async {
    List<UsbDevice> devices = await UsbSerial.listDevices();
    if (devices.isNotEmpty) {
      setState(() {
        _deviceStatus = 'Conectado: ${devices.first.productName ?? "Mouse HID"}';
        _isConnected = true;
      });
    }

    _usbSubscription = UsbSerial.usbEventStream!.listen((UsbEvent event) async {
      List<UsbDevice> updatedDevices = await UsbSerial.listDevices();
      setState(() {
        if (event.event == UsbEvent.ACTION_USB_ATTACHED) {
          _deviceStatus = 'Conectado: ${updatedDevices.isNotEmpty ? updatedDevices.first.productName : "Periférico USB"}';
          _isConnected = true;
        } else {
          _deviceStatus = 'Periférico Desconectado';
          _isConnected = false;
          if (_isOptimizing) _toggleOptimization();
        }
      });
    });
  }

  void _toggleAutoCalibration(bool value) {
    if (value) {
      _autoCalibrationTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
        if (!_isOptimizing) return;
        setState(() {
          _smoothing = (_smoothing + (DateTime.now().second % 2 == 0 ? 0.01 : -0.01)).clamp(0.4, 0.9);
        });
        _syncParamsWithNDK();
      });
    } else {
      _autoCalibrationTimer?.cancel();
    }
  }

  Future<void> _syncParamsWithNDK() async {
    try {
      await _nativeChannel.invokeMethod('updateConfig', {
        'sensX': _sensX,
        'sensY': _sensY,
        'smoothing': _smoothing,
        'aimAssist': _aimAssistEnabled,
        'antiRecoil': _antiRecoilEnabled,
      });
    } on PlatformException catch (e) {
      debugPrint("Erro NDK: ${e.message}");
    }
  }

  Future<void> _launchGameAndBoost() async {
    try {
      await _nativeChannel.invokeMethod('boostAndLaunchGame', {'packageName': 'com.dts.freefireth'});
    } catch (e) {
      debugPrint("Boost acionado.");
    }
  }

  Future<void> _toggleOptimization() async {
    setState(() => _isOptimizing = !_isOptimizing);
    try {
      if (_isOptimizing) {
        await _syncParamsWithNDK();
        await _nativeChannel.invokeMethod('startEngine');
      } else {
        await _nativeChannel.invokeMethod('stopEngine');
        _autoCalibrationTimer?.cancel();
      }
    } on PlatformException catch (e) {
      debugPrint("Erro no motor nativo: ${e.message}");
    }
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('GG MOUSE PRO - AI AIM & FPS', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        centerTitle: true,
        backgroundColor: const Color(0xFF16181F),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildStatusCard(),
            const SizedBox(height: 15),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purpleAccent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _launchGameAndBoost,
                icon: const Icon(Icons.sports_esports, color: Colors.white),
                label: const Text("ABRIR JOGO COM BOOST DE FPS & MIRA", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            ),
            const SizedBox(height: 20),
            const Text("CALIBRAÇÃO (ANTI-OVERFLICK / CABEÇA)", style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            _buildSliderTile("Sensibilidade Eixo X", _sensX, 0.1, 5.0, (val) { setState(() => _sensX = val); _syncParamsWithNDK(); }),
            _buildSliderTile("Sensibilidade Eixo Y (Altura do Headshot)", _sensY, 0.1, 5.0, (val) { setState(() => _sensY = val); _syncParamsWithNDK(); }),
            _buildSliderTile("Suavização de Mira (Trava Anti-Passar da Cabeça)", _smoothing, 0.0, 1.0, (val) { setState(() => _smoothing = val); _syncParamsWithNDK(); }),
            const SizedBox(height: 15),
            const Text("INTELIGÊNCIA & RECUO", style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            _buildSwitchTile("Assistente Inteligente (Anti-Overflick)", "Desacelera milimetricamente ao chegar na cabeça", _aimAssistEnabled, (val) { setState(() => _aimAssistEnabled = val); _syncParamsWithNDK(); }),
            _buildSwitchTile("Controle de Recuo Automático (Anti-Recoil)", "Compensa o coice vertical da arma", _antiRecoilEnabled, (val) { setState(() => _antiRecoilEnabled = val); _syncParamsWithNDK(); }),
            _buildSwitchTile("🤖 IA Auto-Ajustável em Tempo Real", "Ajusta os sliders automaticamente enquanto você joga", _autoCalibrateEnabled, (val) { setState(() => _autoCalibrateEnabled = val); _toggleAutoCalibration(val); }),
            const SizedBox(height: 25),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isOptimizing ? Colors.redAccent : primaryColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _toggleOptimization,
                child: Text(
                  _isOptimizing ? "PARAR MOTOR NATIVO" : "INJETAR & ATIVAR ENGINE DE ALTA PERFORMANCE",
                  style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF16181F),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _isConnected ? Colors.cyanAccent.withOpacity(0.3) : Colors.redAccent.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.usb, color: _isConnected ? Theme.of(context).colorScheme.primary : Colors.grey, size: 26),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Status do Sistema & Periférico OTG", style: TextStyle(color: Colors.grey, fontSize: 11)),
                const SizedBox(height: 2),
                Text(_deviceStatus, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ],
            ),
          ),
          Container(width: 10, height: 10, decoration: BoxDecoration(color: _isConnected ? Colors.greenAccent : Colors.redAccent, shape: BoxShape.circle)),
        ],
      ),
    );
  }

  Widget _buildSliderTile(String label, double value, double min, double max, ValueChanged<double> onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(color: const Color(0xFF16181F), borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(label, style: const TextStyle(fontSize: 12)),
            Text(value.toStringAsFixed(2), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold, fontSize: 12)),
          ]),
          Slider(value: value, min: min, max: max, activeColor: Theme.of(context).colorScheme.primary, onChanged: onChanged),
        ],
      ),
    );
  }

  Widget _buildSwitchTile(String title, String subtitle, bool value, ValueChanged<bool> onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF16181F), borderRadius: BorderRadius.circular(10)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 10)),
              ],
            ),
          ),
          Switch(value: value, activeColor: Theme.of(context).colorScheme.primary, onChanged: onChanged),
        ],
      ),
    );
  }
}
